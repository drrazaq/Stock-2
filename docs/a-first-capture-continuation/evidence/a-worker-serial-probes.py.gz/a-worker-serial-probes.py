import pathlib,subprocess,os,time,json,signal,sys
out=pathlib.Path(__file__).parent;node='/workspace/milestones/nov2-watcher-incident/node20/bin/node';env={'PATH':os.environ['PATH']};rows=[]
lock=out/'synthetic.lock';lock.touch(exist_ok=True);lock.chmod(0o600)
cases=[('python',['python3','-c','print("PYTHON_OK")'],5),('flock-version',['flock','--version'],5),('node-version',[node,'--version'],5),('node-execute',[node,'-e','process.stdout.write("NODE_OK")'],15),('flock-echo',['flock','--exclusive','--nonblock','--conflict-exit-code','73',str(lock),'/bin/echo','FLOCK_OK'],5),('flock-node',['flock','--exclusive','--nonblock','--conflict-exit-code','73',str(lock),node,'-e','process.stdout.write("WORKER_OK")'],15),('node-small-pool-diagnostic',[node,'--v8-pool-size=1','-e','process.stdout.write("SMALL_POOL_OK")'],15)]
for name,cmd,limit in cases:
 start=time.monotonic();p=None;timed=False
 try:
  p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,start_new_session=True)
  try:stdout,stderr=p.communicate(timeout=limit)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate(timeout=5)
  row={'name':name,'exit':p.returncode,'timeout':timed,'deadlineSeconds':limit,'seconds':round(time.monotonic()-start,3),'stdout':stdout.decode(errors='replace'),'stderr':stderr.decode(errors='replace')}
 except OSError as e:row={'name':name,'launchError':str(e),'errno':e.errno}
 rows.append(row);(out/'serial-probes.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
print('SERIAL_COMPLETE',flush=True)
