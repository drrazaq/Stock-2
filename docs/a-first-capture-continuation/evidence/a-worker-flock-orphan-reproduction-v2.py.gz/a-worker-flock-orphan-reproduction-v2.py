import pathlib,subprocess,os,time,json,signal,ctypes
out=pathlib.Path(__file__).parent
libc=ctypes.CDLL(None,use_errno=True)
if libc.prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'test subreaper unavailable')
rows=[]
for mode,flags in [('original-fork',[]),('no-fork',['--no-fork'])]:
 folder=out/(mode+'-v2');folder.mkdir(exist_ok=False);lock=folder/'lock';lock.touch();ready=folder/'ready';late=folder/'late'
 script='import pathlib,time,os;pathlib.Path('+repr(str(ready))+').write_text(str(os.getpid()));time.sleep(0.6);pathlib.Path('+repr(str(late))+').write_text("SYNTHETIC_LATE_WRITE")'
 p=subprocess.Popen(['flock',*flags,'--exclusive','--nonblock','--conflict-exit-code','73',str(lock),'python3','-c',script],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 deadline=time.monotonic()+3
 while not ready.exists() and p.poll() is None and time.monotonic()<deadline:time.sleep(.005)
 if not ready.exists():raise RuntimeError('PROBE_START_UNKNOWN:'+mode)
 worker=int(ready.read_text());before=subprocess.run(['flock','-n','-E','73',str(lock),'/bin/true'],capture_output=True,timeout=3).returncode;terminatedAt=time.monotonic();p.terminate();p.wait(timeout=3)
 held=subprocess.run(['flock','-n','-E','73',str(lock),'/bin/true'],capture_output=True,timeout=3).returncode
 time.sleep(.7);stdout,stderr=p.communicate(timeout=3)
 row={'mode':mode,'launcherPid':p.pid,'workerPid':worker,'launcherExit':p.returncode,'lockRefusalBeforeTermination':before,'lockRefusalAfterLauncherExit':held,'lateWriteAfterLauncherExit':late.exists(),'originalLockStillExists':lock.exists(),'stderr':stderr.decode()};rows.append(row)
 while True:
  try:pid,status=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid==0:break
 print(json.dumps(row),flush=True)
(out/'flock-orphan-reproduction-v2.json').write_text(json.dumps(rows,indent=2)+'\n')
assert rows[0]['lateWriteAfterLauncherExit'];assert rows[0]['lockRefusalBeforeTermination']==73
assert not rows[1]['lateWriteAfterLauncherExit'] and rows[1]['lockRefusalAfterLauncherExit']==0
print('ORIGINAL_ORPHAN_REPRODUCED_NO_FORK_CONTROL_PASSES',flush=True)
