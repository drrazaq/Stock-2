export declare function getUploadChunkSize(): number;
export declare function getRuntimeToken(): string;
export declare function getResultsServiceUrl(): string;
export declare function isGhes(): boolean;
export declare function getGitHubWorkspaceDir(): string;
export declare function getConcurrency(): number;
export declare function getUploadChunkTimeout(): number;
export declare function getMaxArtifactListCount(): number;
