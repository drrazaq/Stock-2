import { ArtifactServiceClientJSON } from '../../generated/index.js';
export declare function internalArtifactTwirpClient(options?: {
    maxAttempts?: number;
    retryIntervalMs?: number;
    retryMultiplier?: number;
}): ArtifactServiceClientJSON;
