import { WaterMarkedUploadStream } from './stream.js';
export interface BlobUploadResponse {
    /**
     * The total reported upload size in bytes. Empty if the upload failed
     */
    uploadSize?: number;
    /**
     * The SHA256 hash of the uploaded file. Empty if the upload failed
     */
    sha256Hash?: string;
}
export declare function uploadToBlobStorage(authenticatedUploadURL: string, uploadStream: WaterMarkedUploadStream, contentType: string): Promise<BlobUploadResponse>;
