import { Timestamp } from '../../generated/index.js';
export declare function getExpiration(retentionDays?: number): Timestamp | undefined;
