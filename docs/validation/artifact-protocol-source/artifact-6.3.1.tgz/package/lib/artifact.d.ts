import { ArtifactClient } from './internal/client.js';
export * from './internal/shared/interfaces.js';
export * from './internal/shared/errors.js';
export * from './internal/client.js';
declare const client: ArtifactClient;
export default client;
