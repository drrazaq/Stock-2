import { ServiceType } from "@protobuf-ts/runtime-rpc";
import type { BinaryWriteOptions } from "@protobuf-ts/runtime";
import type { IBinaryWriter } from "@protobuf-ts/runtime";
import type { BinaryReadOptions } from "@protobuf-ts/runtime";
import type { IBinaryReader } from "@protobuf-ts/runtime";
import type { PartialMessage } from "@protobuf-ts/runtime";
import { MessageType } from "@protobuf-ts/runtime";
import { Int64Value } from "../../../google/protobuf/wrappers.js";
import { StringValue } from "../../../google/protobuf/wrappers.js";
import { Timestamp } from "../../../google/protobuf/timestamp.js";
/**
 * @generated from protobuf message github.actions.results.api.v1.CreateArtifactRequest
 */
export interface CreateArtifactRequest {
    /**
     * @generated from protobuf field: string workflow_run_backend_id = 1;
     */
    workflowRunBackendId: string;
    /**
     * @generated from protobuf field: string workflow_job_run_backend_id = 2;
     */
    workflowJobRunBackendId: string;
    /**
     * @generated from protobuf field: string name = 3;
     */
    name: string;
    /**
     * @generated from protobuf field: google.protobuf.Timestamp expires_at = 4;
     */
    expiresAt?: Timestamp;
    /**
     * @generated from protobuf field: int32 version = 5;
     */
    version: number;
    /**
     * @generated from protobuf field: google.protobuf.StringValue mime_type = 6;
     */
    mimeType?: StringValue;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.CreateArtifactResponse
 */
export interface CreateArtifactResponse {
    /**
     * @generated from protobuf field: bool ok = 1;
     */
    ok: boolean;
    /**
     * @generated from protobuf field: string signed_upload_url = 2;
     */
    signedUploadUrl: string;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.FinalizeArtifactRequest
 */
export interface FinalizeArtifactRequest {
    /**
     * @generated from protobuf field: string workflow_run_backend_id = 1;
     */
    workflowRunBackendId: string;
    /**
     * @generated from protobuf field: string workflow_job_run_backend_id = 2;
     */
    workflowJobRunBackendId: string;
    /**
     * @generated from protobuf field: string name = 3;
     */
    name: string;
    /**
     * @generated from protobuf field: int64 size = 4;
     */
    size: string;
    /**
     * @generated from protobuf field: google.protobuf.StringValue hash = 5;
     */
    hash?: StringValue;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.FinalizeArtifactResponse
 */
export interface FinalizeArtifactResponse {
    /**
     * @generated from protobuf field: bool ok = 1;
     */
    ok: boolean;
    /**
     * @generated from protobuf field: int64 artifact_id = 2;
     */
    artifactId: string;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.ListArtifactsRequest
 */
export interface ListArtifactsRequest {
    /**
     * The backend plan ID
     *
     * @generated from protobuf field: string workflow_run_backend_id = 1;
     */
    workflowRunBackendId: string;
    /**
     * The backend job ID
     *
     * @generated from protobuf field: string workflow_job_run_backend_id = 2;
     */
    workflowJobRunBackendId: string;
    /**
     * Name of the artifact to filter on
     *
     * @generated from protobuf field: google.protobuf.StringValue name_filter = 3;
     */
    nameFilter?: StringValue;
    /**
     * Monolith Database ID of the artifact to filter on
     *
     * @generated from protobuf field: google.protobuf.Int64Value id_filter = 4;
     */
    idFilter?: Int64Value;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.ListArtifactsResponse
 */
export interface ListArtifactsResponse {
    /**
     * @generated from protobuf field: repeated github.actions.results.api.v1.ListArtifactsResponse.MonolithArtifact artifacts = 1;
     */
    artifacts: ListArtifactsResponse_MonolithArtifact[];
}
/**
 * @generated from protobuf message github.actions.results.api.v1.ListArtifactsResponse.MonolithArtifact
 */
export interface ListArtifactsResponse_MonolithArtifact {
    /**
     * The backend plan ID
     *
     * @generated from protobuf field: string workflow_run_backend_id = 1;
     */
    workflowRunBackendId: string;
    /**
     * The backend job ID
     *
     * @generated from protobuf field: string workflow_job_run_backend_id = 2;
     */
    workflowJobRunBackendId: string;
    /**
     * Monolith database ID of the artifact
     *
     * @generated from protobuf field: int64 database_id = 3;
     */
    databaseId: string;
    /**
     * Name of the artifact
     *
     * @generated from protobuf field: string name = 4;
     */
    name: string;
    /**
     * Size of the artifact in bytes
     *
     * @generated from protobuf field: int64 size = 5;
     */
    size: string;
    /**
     * When the artifact was created in the monolith
     *
     * @generated from protobuf field: google.protobuf.Timestamp created_at = 6;
     */
    createdAt?: Timestamp;
    /**
     * The SHA-256 digest of the artifact, calculated on upload for upload-artifact v4 & newer
     *
     * @generated from protobuf field: google.protobuf.StringValue digest = 7;
     */
    digest?: StringValue;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.GetSignedArtifactURLRequest
 */
export interface GetSignedArtifactURLRequest {
    /**
     * @generated from protobuf field: string workflow_run_backend_id = 1;
     */
    workflowRunBackendId: string;
    /**
     * @generated from protobuf field: string workflow_job_run_backend_id = 2;
     */
    workflowJobRunBackendId: string;
    /**
     * @generated from protobuf field: string name = 3;
     */
    name: string;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.GetSignedArtifactURLResponse
 */
export interface GetSignedArtifactURLResponse {
    /**
     * @generated from protobuf field: string signed_url = 1;
     */
    signedUrl: string;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.DeleteArtifactRequest
 */
export interface DeleteArtifactRequest {
    /**
     * @generated from protobuf field: string workflow_run_backend_id = 1;
     */
    workflowRunBackendId: string;
    /**
     * @generated from protobuf field: string workflow_job_run_backend_id = 2;
     */
    workflowJobRunBackendId: string;
    /**
     * @generated from protobuf field: string name = 3;
     */
    name: string;
}
/**
 * @generated from protobuf message github.actions.results.api.v1.DeleteArtifactResponse
 */
export interface DeleteArtifactResponse {
    /**
     * @generated from protobuf field: bool ok = 1;
     */
    ok: boolean;
    /**
     * @generated from protobuf field: int64 artifact_id = 2;
     */
    artifactId: string;
}
declare class CreateArtifactRequest$Type extends MessageType<CreateArtifactRequest> {
    constructor();
    create(value?: PartialMessage<CreateArtifactRequest>): CreateArtifactRequest;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: CreateArtifactRequest): CreateArtifactRequest;
    internalBinaryWrite(message: CreateArtifactRequest, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.CreateArtifactRequest
 */
export declare const CreateArtifactRequest: CreateArtifactRequest$Type;
declare class CreateArtifactResponse$Type extends MessageType<CreateArtifactResponse> {
    constructor();
    create(value?: PartialMessage<CreateArtifactResponse>): CreateArtifactResponse;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: CreateArtifactResponse): CreateArtifactResponse;
    internalBinaryWrite(message: CreateArtifactResponse, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.CreateArtifactResponse
 */
export declare const CreateArtifactResponse: CreateArtifactResponse$Type;
declare class FinalizeArtifactRequest$Type extends MessageType<FinalizeArtifactRequest> {
    constructor();
    create(value?: PartialMessage<FinalizeArtifactRequest>): FinalizeArtifactRequest;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: FinalizeArtifactRequest): FinalizeArtifactRequest;
    internalBinaryWrite(message: FinalizeArtifactRequest, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.FinalizeArtifactRequest
 */
export declare const FinalizeArtifactRequest: FinalizeArtifactRequest$Type;
declare class FinalizeArtifactResponse$Type extends MessageType<FinalizeArtifactResponse> {
    constructor();
    create(value?: PartialMessage<FinalizeArtifactResponse>): FinalizeArtifactResponse;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: FinalizeArtifactResponse): FinalizeArtifactResponse;
    internalBinaryWrite(message: FinalizeArtifactResponse, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.FinalizeArtifactResponse
 */
export declare const FinalizeArtifactResponse: FinalizeArtifactResponse$Type;
declare class ListArtifactsRequest$Type extends MessageType<ListArtifactsRequest> {
    constructor();
    create(value?: PartialMessage<ListArtifactsRequest>): ListArtifactsRequest;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: ListArtifactsRequest): ListArtifactsRequest;
    internalBinaryWrite(message: ListArtifactsRequest, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.ListArtifactsRequest
 */
export declare const ListArtifactsRequest: ListArtifactsRequest$Type;
declare class ListArtifactsResponse$Type extends MessageType<ListArtifactsResponse> {
    constructor();
    create(value?: PartialMessage<ListArtifactsResponse>): ListArtifactsResponse;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: ListArtifactsResponse): ListArtifactsResponse;
    internalBinaryWrite(message: ListArtifactsResponse, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.ListArtifactsResponse
 */
export declare const ListArtifactsResponse: ListArtifactsResponse$Type;
declare class ListArtifactsResponse_MonolithArtifact$Type extends MessageType<ListArtifactsResponse_MonolithArtifact> {
    constructor();
    create(value?: PartialMessage<ListArtifactsResponse_MonolithArtifact>): ListArtifactsResponse_MonolithArtifact;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: ListArtifactsResponse_MonolithArtifact): ListArtifactsResponse_MonolithArtifact;
    internalBinaryWrite(message: ListArtifactsResponse_MonolithArtifact, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.ListArtifactsResponse.MonolithArtifact
 */
export declare const ListArtifactsResponse_MonolithArtifact: ListArtifactsResponse_MonolithArtifact$Type;
declare class GetSignedArtifactURLRequest$Type extends MessageType<GetSignedArtifactURLRequest> {
    constructor();
    create(value?: PartialMessage<GetSignedArtifactURLRequest>): GetSignedArtifactURLRequest;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: GetSignedArtifactURLRequest): GetSignedArtifactURLRequest;
    internalBinaryWrite(message: GetSignedArtifactURLRequest, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.GetSignedArtifactURLRequest
 */
export declare const GetSignedArtifactURLRequest: GetSignedArtifactURLRequest$Type;
declare class GetSignedArtifactURLResponse$Type extends MessageType<GetSignedArtifactURLResponse> {
    constructor();
    create(value?: PartialMessage<GetSignedArtifactURLResponse>): GetSignedArtifactURLResponse;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: GetSignedArtifactURLResponse): GetSignedArtifactURLResponse;
    internalBinaryWrite(message: GetSignedArtifactURLResponse, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.GetSignedArtifactURLResponse
 */
export declare const GetSignedArtifactURLResponse: GetSignedArtifactURLResponse$Type;
declare class DeleteArtifactRequest$Type extends MessageType<DeleteArtifactRequest> {
    constructor();
    create(value?: PartialMessage<DeleteArtifactRequest>): DeleteArtifactRequest;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: DeleteArtifactRequest): DeleteArtifactRequest;
    internalBinaryWrite(message: DeleteArtifactRequest, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.DeleteArtifactRequest
 */
export declare const DeleteArtifactRequest: DeleteArtifactRequest$Type;
declare class DeleteArtifactResponse$Type extends MessageType<DeleteArtifactResponse> {
    constructor();
    create(value?: PartialMessage<DeleteArtifactResponse>): DeleteArtifactResponse;
    internalBinaryRead(reader: IBinaryReader, length: number, options: BinaryReadOptions, target?: DeleteArtifactResponse): DeleteArtifactResponse;
    internalBinaryWrite(message: DeleteArtifactResponse, writer: IBinaryWriter, options: BinaryWriteOptions): IBinaryWriter;
}
/**
 * @generated MessageType for protobuf message github.actions.results.api.v1.DeleteArtifactResponse
 */
export declare const DeleteArtifactResponse: DeleteArtifactResponse$Type;
/**
 * @generated ServiceType for protobuf service github.actions.results.api.v1.ArtifactService
 */
export declare const ArtifactService: ServiceType;
export {};
